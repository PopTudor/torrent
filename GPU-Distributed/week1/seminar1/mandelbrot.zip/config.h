#define WIDTH 4096
#define HEIGHT 4096

#define MAX_ITERATION 5000

#define THREADS 8
#define REPEAT 10

#define IMAGE "./%s_%02d.png"
#define REPORT "./report.txt"
